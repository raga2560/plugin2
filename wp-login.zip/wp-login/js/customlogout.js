
function jslogoutfunction( ) {

 alert("hi");
}
